"""Render a generated Composition to samples.

Each voice is rendered onto its own scratch bus so its effects chain can be
applied to the whole part — a reverb tail or a delay repeat has to be allowed
to run past the note that caused it, which per-note processing would chop off.
Only one scratch buffer exists at a time, so this costs memory for one voice,
not for all of them.

Identical notes are synthesised once and reused. A three-minute piece can ask
for a couple of thousand notes, most of them repeats.
"""

from __future__ import annotations

from typing import Callable, Optional

import numpy as np

from compex.config import SAMPLE_RATE
from compex.dsp import balance, drums, effects, engines, filters, fx
from compex.generate.compose import Composition
from compex.generate.palette import ROLE_PAD, ROLE_PERC, VoiceSpec
from compex.generate.write import GHOST_MARK

TAIL_SECONDS = 3.5
REFERENCE_KIT = 3.0    # the kit size the per-drum gains were written for
MIN_KIT_TRIM = 0.45

#: Ghosts are lowpassed before they are mixed in. Not for tidiness — a line
#: with its top taken off is heard as *behind* the one that beat it rather than
#: as a second line competing with it, which is the difference between a haze
#: and a mess.
GHOST_CUTOFF = 1800.0

#: The voices the sidechain ducks everything else under. They are named here
#: rather than inline because the mixer has to know about them: a voice the
#: duck already clears a hole for must not *also* be trimmed up for finding its
#: band crowded, which is the same room counted twice.
DUCK_TRIGGERS = frozenset({"kick", "boom"})
VARIANTS = 3           # one-shot variants per voice, cycled so repeats still vary
DUCK_DEPTH = 0.42
DUCK_RELEASE = 0.055

ProgressFn = Optional[Callable[[float, str], None]]


def survey(composition: Composition, sample_rate: int = SAMPLE_RATE) -> balance.Mix:
    """Ask every voice what it sounds like, and decide who needs room.

    One representative note per voice, through its own effects chain, weighted
    by how much that voice actually plays. Cheap — a handful of notes — and it
    is the only way to know that this pad is under a noise wash rather than
    under a sub bass, which is the difference between present and inaudible.
    """
    specs = {voice.voice_id: voice for voice in composition.voices}
    played: dict[str, float] = {}
    for note in composition.notes:
        played[note.voice] = played.get(note.voice, 0.0) + note.velocity * note.duration
    for stroke in composition.strokes:
        played[stroke.voice] = played.get(stroke.voice, 0.0) + stroke.velocity * 0.25

    pitched = [n for n in composition.notes]
    middle: dict[str, float] = {}
    for note in pitched:
        middle.setdefault(note.voice, note.pitch)

    kit_size = sum(1 for v in composition.voices if v.role == ROLE_PERC)
    trim = kit_trim(kit_size)

    energies: dict[str, tuple[str, tuple[float, ...], float]] = {}
    for voice_id, weight in played.items():
        spec = specs.get(voice_id)
        if spec is None or weight <= 0:
            continue
        if spec.role == ROLE_PERC:
            sample = drums.render_drum(spec, sample_rate, composition.seed, 0)
            gain = spec.gain * trim
        else:
            count = int(sample_rate * 1.2)
            sample = engines.render_note(spec, _hz(middle.get(voice_id, 60.0)),
                                         count, sample_rate, composition.seed, 0)
            if spec.effects:
                sample = effects.apply_chain(sample, sample_rate, spec.effects)
            gain = spec.gain
        bands = balance.band_energy(sample, sample_rate)
        # Squared, like the gain beside it: these are energies, and salience is
        # a correction to apparent *amplitude*.
        sharp = balance.salience(sample, sample_rate)
        scale = weight * gain * gain * sharp * sharp
        energies[voice_id] = (spec.role, tuple(value * scale for value in bands), gain)

    # A kick is never buried — everything else is ducked out of its way on
    # every hit. Measured before this line existed: the mixer read the low band
    # as crowded (a pad and a bass live there), decided the kick was losing it,
    # and applied the maximum lift on top of the hole the duck had already cut.
    return balance.weigh(energies, played, protected=DUCK_TRIGGERS)


def render_composition(composition: Composition, master_gain: float = 0.89,
                       progress: ProgressFn = None,
                       ghost_gain: float = 0.0) -> np.ndarray:
    """Render ``composition`` to mono float samples in ``[-1, 1]``.

    ``ghost_gain`` is how loudly the lines the composer decided against are
    heard under the ones that beat them. Zero is the engine as it was before
    the ghosts existed.
    """
    if not 0.0 < master_gain <= 1.0:
        raise ValueError(f"master_gain must be in (0, 1], got {master_gain}")
    if not 0.0 <= ghost_gain <= 1.0:
        raise ValueError(f"ghost_gain must be in [0, 1], got {ghost_gain}")

    seconds_per_beat = composition.seconds_per_beat
    total = int((composition.total_seconds + TAIL_SECONDS) * SAMPLE_RATE)
    if total <= 0:
        raise ValueError("composition has no length")

    melodic = np.zeros(total, dtype=np.float64)
    percussion = np.zeros(total, dtype=np.float64)

    _report(progress, 0.03, "listening to each voice")
    mix = survey(composition)

    _render_voices(melodic, composition, seconds_per_beat, progress, mix.trims())

    _report(progress, 0.80, f"placing {len(composition.strokes)} strokes")
    _render_strokes(percussion, composition, seconds_per_beat, mix.trims())

    if ghost_gain > 0 and (composition.ghosts or composition.ghost_strokes):
        _report(progress, 0.86, f"{len(composition.ghosts)} notes it decided against")
        melodic += _render_ghosts(total, composition, seconds_per_beat) * ghost_gain

    _report(progress, 0.90, "ducking against the kick")
    melodic *= _sidechain(total, composition, seconds_per_beat)

    _report(progress, 0.95, "mastering")
    master = filters.highpass(melodic + percussion, SAMPLE_RATE, 24.0)
    master = fx.peak_normalise(master, 0.97) * master_gain
    master = fx.fade_edges(fx.limit(master), SAMPLE_RATE, 0.02)

    _report(progress, 1.0, "done")
    return master


def render_stems(composition: Composition, master_gain: float = 0.89,
                 ghost_gain: float = 0.0) -> dict[str, np.ndarray]:
    """Every voice on its own, at exactly the level it has in the mix.

    Summing these gives the master back to within the mastering stage, which is
    the property that makes them useful: a stem is not a re-render of the voice
    in isolation, it is the thing that actually went in. Anything else and the
    stems are a different piece that happens to sound similar.

    Keys are voice ids, plus ``ghosts`` for the lines and grooves it decided
    against and ``master`` for the finished mix.
    """
    if not 0.0 < master_gain <= 1.0:
        raise ValueError(f"master_gain must be in (0, 1], got {master_gain}")
    if not 0.0 <= ghost_gain <= 1.0:
        raise ValueError(f"ghost_gain must be in [0, 1], got {ghost_gain}")

    seconds_per_beat = composition.seconds_per_beat
    total = int((composition.total_seconds + TAIL_SECONDS) * SAMPLE_RATE)
    if total <= 0:
        raise ValueError("composition has no length")

    mix = survey(composition)
    trims = mix.trims()
    stems: dict[str, np.ndarray] = {}

    for voice in composition.voices:
        bus = np.zeros(total, dtype=np.float64)
        if voice.role == ROLE_PERC:
            _render_strokes(bus, composition, seconds_per_beat, trims, only=voice.voice_id)
        else:
            _render_voices(bus, composition, seconds_per_beat, None, trims,
                           only=voice.voice_id)
        if np.any(bus):
            stems[voice.voice_id] = bus

    if ghost_gain > 0 and (composition.ghosts or composition.ghost_strokes):
        stems["ghosts"] = _render_ghosts(total, composition, seconds_per_beat) * ghost_gain

    # The sidechain is a property of the mix, not of any one voice, so it is
    # applied to the melodic stems the same way the master applies it. Without
    # this the stems would sum to something the master never was.
    duck = _sidechain(total, composition, seconds_per_beat)
    percussive = {voice.voice_id for voice in composition.voices if voice.role == ROLE_PERC}
    for name, bus in stems.items():
        if name not in percussive:
            stems[name] = bus * duck

    stems["master"] = render_composition(composition, master_gain, None, ghost_gain)
    return stems


def _render_voices(bus: np.ndarray, composition: Composition, seconds_per_beat: float,
                   progress: ProgressFn, trims: dict[str, float] | None = None,
                   only: str | None = None) -> None:
    """One voice at a time: synthesise its notes, run its effects, fold it in."""
    # Grouped by (voice, state), not by voice: an instrument drifts as the
    # piece goes, so the same voice is several instruments over eight minutes
    # and each one has to be rendered as what it was at the time.
    grouped: dict[tuple[str, int], list] = {}
    for note in composition.notes:
        if only is not None and note.voice != only:
            continue
        grouped.setdefault((note.voice, note.timbre), []).append(note)

    for position, ((voice_id, timbre), notes) in enumerate(grouped.items()):
        spec = composition.state(voice_id, timbre)
        if spec is None:
            continue  # a voice that vanished between compose and render — skip, do not crash

        _report(progress, 0.05 + 0.7 * position / max(1, len(grouped)),
                f"{spec.engine} ({len(notes)} notes)"
                + (f" → {', '.join(spec.effect_names())}" if spec.effects else ""))

        scratch = np.zeros(len(bus), dtype=np.float64)
        cache: dict[tuple, np.ndarray] = {}
        for order, note in enumerate(notes):
            count = _note_samples(spec, note.duration, seconds_per_beat)
            variant = order % VARIANTS
            key = (round(note.pitch, 2), count, variant)

            sample = cache.get(key)
            if sample is None:
                sample = engines.render_note(
                    spec, _hz(note.pitch), count, SAMPLE_RATE, composition.seed, variant
                )
                cache[key] = sample
            _add_at(scratch, sample * note.velocity, _sample_at(note.start, seconds_per_beat))

        if spec.effects:
            scratch = effects.apply_chain(scratch, SAMPLE_RATE, spec.effects)
        bus += scratch * spec.gain * (trims or {}).get(voice_id, 1.0)


def kit_trim(count: int) -> float:
    """How much to hold the kit back for having this many drums in it.

    Seven drums should not be seven times one drum. Each voice was given a
    gain as if it were playing alone, so a dense kit arrived at roughly twice
    the level of everything melodic put together — measured, not guessed.
    Square root rather than linear because that is roughly how loudness adds
    when the hits are not simultaneous.
    """
    if count <= 0:
        return 1.0
    return max(MIN_KIT_TRIM, min(1.0, (REFERENCE_KIT / count) ** 0.5))


def _render_strokes(bus: np.ndarray, composition: Composition,
                    seconds_per_beat: float, trims: dict[str, float] | None = None,
                    only: str | None = None) -> None:
    kit = {voice.voice_id: voice for voice in composition.voices if voice.role == ROLE_PERC}
    trim = kit_trim(len(kit))
    cache: dict[tuple[str, int], np.ndarray] = {}

    for position, stroke in enumerate(composition.strokes):
        spec = kit.get(stroke.voice)
        if spec is None or (only is not None and stroke.voice != only):
            continue
        variant = position % VARIANTS
        key = (stroke.voice, variant)
        sample = cache.get(key)
        if sample is None:
            sample = drums.render_drum(spec, SAMPLE_RATE, composition.seed, variant)
            cache[key] = sample
        _add_at(bus, sample * stroke.velocity * spec.gain * trim
                * (trims or {}).get(stroke.voice, 1.0),
                _sample_at(stroke.start, seconds_per_beat))


def _render_ghosts(total: int, composition: Composition,
                   seconds_per_beat: float) -> np.ndarray:
    """Render the lines that lost their auditions, on their own bus.

    They use the voice that beat them — same engine, same character — because
    a ghost is the same instrument playing what it nearly played, not a
    different instrument commenting on it.
    """
    bus = np.zeros(total, dtype=np.float64)
    specs = {voice.voice_id: voice for voice in composition.voices}

    grouped: dict[str, list] = {}
    for note in composition.ghosts:
        grouped.setdefault(note.voice, []).append(note)

    for voice_id, notes in grouped.items():
        spec = specs.get(voice_id.replace(GHOST_MARK, ""))
        if spec is None:
            continue
        cache: dict[tuple, np.ndarray] = {}
        for order, note in enumerate(notes):
            count = _note_samples(spec, note.duration, seconds_per_beat)
            key = (round(note.pitch, 2), count, order % VARIANTS)
            sample = cache.get(key)
            if sample is None:
                sample = engines.render_note(spec, _hz(note.pitch), count, SAMPLE_RATE,
                                             composition.seed, order % VARIANTS)
                cache[key] = sample
            _add_at(bus, sample * note.velocity, _sample_at(note.start, seconds_per_beat))

    _ghost_strokes(bus, composition, seconds_per_beat)
    return filters.lowpass(bus, SAMPLE_RATE, GHOST_CUTOFF, order=2)


def _ghost_strokes(bus: np.ndarray, composition: Composition,
                   seconds_per_beat: float) -> None:
    """The hits that did not land, onto the same blurred bus as the lines.

    They share the bus rather than getting their own on purpose: the lowpass is
    what turns a rejected drum into the memory of one, and a kit playing its
    runners-up at full bandwidth is a second kit, not a doubt.
    """
    kit = {voice.voice_id: voice for voice in composition.voices if voice.role == ROLE_PERC}
    trim = kit_trim(len(kit))
    cache: dict[tuple[str, int], np.ndarray] = {}
    for order, stroke in enumerate(composition.ghost_strokes):
        spec = kit.get(stroke.voice.replace(GHOST_MARK, ""))
        if spec is None:
            continue
        key = (stroke.voice, order % VARIANTS)
        sample = cache.get(key)
        if sample is None:
            sample = drums.render_drum(spec, SAMPLE_RATE, composition.seed, order % VARIANTS)
            cache[key] = sample
        _add_at(bus, sample * stroke.velocity * spec.gain * trim,
                _sample_at(stroke.start, seconds_per_beat))


def _sidechain(total: int, composition: Composition, seconds_per_beat: float) -> np.ndarray:
    """Duck the melodic bus under every kick. Without it the low end turns to mud."""
    duck = np.ones(total, dtype=np.float64)
    kicks = [stroke for stroke in composition.strokes if stroke.voice in DUCK_TRIGGERS]
    if not kicks:
        return duck

    window = int(0.17 * SAMPLE_RATE)
    shape = 1.0 - DUCK_DEPTH * np.exp(-np.arange(window) / (DUCK_RELEASE * SAMPLE_RATE))
    for stroke in kicks:
        start = _sample_at(stroke.start, seconds_per_beat)
        end = min(total, start + window)
        if end > start:
            duck[start:end] = np.minimum(duck[start:end], shape[: end - start])
    return duck


def _note_samples(spec: VoiceSpec, duration_beats: float, seconds_per_beat: float) -> int:
    """Note length plus whatever tail this engine needs to ring out."""
    tail = spec.get("release", 0.8) if spec.role == ROLE_PAD else min(
        4.0, max(0.15, spec.get("decay", 1.0))
    )
    return max(64, int((duration_beats * seconds_per_beat + tail) * SAMPLE_RATE))


def _hz(pitch: float) -> float:
    return 440.0 * (2.0 ** ((pitch - 69) / 12.0))


def _add_at(bus: np.ndarray, sample: np.ndarray, offset: int) -> None:
    if offset >= len(bus) or len(sample) == 0:
        return
    end = min(len(bus), offset + len(sample))
    bus[offset:end] += sample[: end - offset]


def _sample_at(beat: float, seconds_per_beat: float) -> int:
    return max(0, int(round(beat * seconds_per_beat * SAMPLE_RATE)))


def _report(progress: ProgressFn, fraction: float, message: str) -> None:
    if progress is not None:
        progress(max(0.0, min(1.0, fraction)), message)
